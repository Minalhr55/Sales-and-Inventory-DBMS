#!/usr/bin/python
import psycopg2
from psycopg2 import Error
import config
def add_new_appt(app_no,status,start_time,end_time):
    try:
        # Connect to an existing database
        #params = config()
        connection = psycopg2.connect(user="postgres",
                                      password="manyatha19",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="hospital")

        # Create a cursor to perform database operations
        cursor = connection.cursor()
        print("****** WELCOME TO HOSPITAL DATABASE ******")
        print("Choose option to execute:\n 1. Simple query \n 2. Complex query \n 3. Functions \n 4. Transactions ")
        print("Type 0 to exit from the interface")
        n = int(input("Enter choice : "))
        while n>4:
            n=int(input("Invalid choice!! \nPlease re-enter choice:"))
        # Executing a SQL query
        while (n != 0):

            if n==1:
                #simple
                print("List of all employees whose salary is greater than 75,000 rupees.")
                cursor.execute("SELECT E_ID, E_NAME, E_SAL FROM EMPLOYEE WHERE E_SAL > 75000 ;")
                break
            elif n==2:
                #complex
                print("Using nested queries retrieve the names of each patient who has a dependent who is younger than the patient.")
                cursor.execute('SELECT PF_NAME, PL_NAME, P_ID  FROM PATIENT AS P WHERE P_ID IN ( SELECT ID FROM RELATIVES AS R WHERE P.P_AGE > R.AGE );')
                break
            elif n==3:
                #functions
                print("Using functions, fetch all the medicine names and cost")
                cursor.callproc("get_med_info", ())
                break
            elif n == 4:
                #stored procedures
                print("Using stored procedures, create a new appointment for a patient and add it to the existing database")

                #cursor.execute("CALL add_new_appt(%s,%s,%s,%s)", (app_no,status,start_time,end_time))
                cursor.callproc("get_emp_name", ())
                break



        # Fetch result
        record = cursor.fetchall()
        print(record, "\n")

    except (Exception, Error) as error:
        print( error)

    finally:
        if (connection):
            connection.commit()

            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")

if __name__ == '__main__':
    add_new_appt(1090, 'GENERAL CHECK UP', '3:00 PM', '7:30 PM');
