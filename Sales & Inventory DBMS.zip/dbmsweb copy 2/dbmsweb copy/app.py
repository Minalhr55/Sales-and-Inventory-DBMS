from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
import psycopg2

app = Flask(__name__, template_folder='templates')
auth = HTTPBasicAuth()

ENV = 'dev'

if ENV == 'dev':
    app.debug = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/databasename'
else:
    app.debug = False
    app.config['SQLALCHEMY_DATABASE_URI'] = ''

con=psycopg2.connect(dbname='postgres',user='postgres',password='1356')
cur=con.cursor()

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

SI_db_username = ['admin','user1','user2']
SI_db_password = ['admin','user1','user2']
        
# Page Routes

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/data')
def data():
    return render_template('data.html')

# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] not in SI_db_username or request.form['password'] not in SI_db_password:
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@app.route('/newuser', methods=['GET', 'POST'])
def newuser():
    #return render_template("Patient.html")
    if request.method  == 'POST':
        # Get Form Fields
        u_id = request.form.get("u_id")
        u_fname = request.form.get("u_fname")
        u_lname = request.form.get("u_lname")
        username = request.form.get("username")
        password = request.form.get("password")
        u_type_id = request.form.get("u_type_id")
        u_loc_id = request.form.get("u_loc_id")
        u_pnumber = request.form.get("u_pnumber")
        cur.execute("INSERT INTO U_USER(u_id,u_fname,u_lname,username,password,u_type_id, u_loc_id, u_pnumber)  VALUES(%s, %s, %s, %s, %s, %s, %s, %s)",(u_id,u_fname,u_lname,username,password,u_type_id,u_loc_id, u_pnumber))
        con.commit()
        #return render_template("HOME.html")
    return render_template("newuser.html")

@app.route('/employee.html')
def employee():
    cur.execute("SELECT * FROM EMPLOYEE")
    data = cur.fetchall()
    return render_template('employee.html', data=data)

@app.route('/customer.html')
def customer():
    cur.execute("SELECT * FROM CUSTOMER")
    data = cur.fetchall()
    return render_template('customer.html', data=data)

@app.route('/job.html')
def job():
    cur.execute("SELECT * FROM JOB")
    data = cur.fetchall()
    return render_template('job.html', data=data)

@app.route('/location.html')
def location():
    cur.execute("SELECT * FROM LOCATION")
    data = cur.fetchall()
    return render_template('location.html', data=data)

@app.route('/supplier.html')
def supplier():
    cur.execute("SELECT * FROM SUPPLIER")
    data = cur.fetchall()
    return render_template('supplier.html', data=data)

@app.route('/product.html')
def product():
    cur.execute("SELECT * FROM PRODUCT")
    data = cur.fetchall()
    return render_template('product.html', data=data)

@app.route('/Type.html')
def Type():
    cur.execute("SELECT * FROM TYPE")
    data = cur.fetchall()
    return render_template('Type.html', data=data)

@app.route('/user.html')
def user():
    cur.execute("SELECT * FROM U_USER")
    data = cur.fetchall()
    return render_template('user.html', data=data)

@app.route('/manager.html')
def manager():
    cur.execute("SELECT * FROM MANAGER")
    data = cur.fetchall()
    return render_template('manager.html',data=data)

@app.route('/complexquery')
def complexquery():
    cur.execute("SELECT U_USER.U_FNAME, U_USER.U_LNAME from U_USER WHERE EXISTS (SELECT U_LOC_ID FROM U_USER WHERE U_TYPE_ID = 3456 EXCEPT (SELECT L_ID FROM LOCATION WHERE L_ID = U_LOC_ID))")
    data = cur.fetchall()
    return render_template('complexquery.html',data=data)

@app.route('/simplequery')
def simplequery():
    cur.execute("SELECT * FROM EMPLOYEE WHERE E_ID=901")
    data = cur.fetchall()
    return render_template('simplequery.html',data=data)

@app.route('/updateproduct')
def updateproduct():
    cur.execute("UPDATE PRODUCT SET qty_stock = qty_stock + 20")
    cur.execute("SELECT * FROM PRODUCT")
    data = cur.fetchall()
    return render_template('updateproduct.html',data=data)

@app.route('/deleteproduct')
def deleteproduct():
    cur.execute("DELETE FROM PRODUCT WHERE p_id=367539")
    cur.execute("SELECT * FROM PRODUCT")
    data = cur.fetchall()
    return render_template('delete.html',data=data)

@app.route('/updateuser', methods=['GET', 'POST'])
def updateuser():
    if request.method  == 'POST':

        # Get Form Fields
        u_id = request.form.get("u_id")
        u_fname = request.form.get("u_fname")
        u_lname = request.form.get("u_lname")
        username = request.form.get("username")
        password = request.form.get("password")
        u_type_id = request.form.get("u_type_id")
        u_loc_id = request.form.get("u_loc_id")
        u_pnumber = request.form.get("u_pnumber")
        cur.execute("UPDATE U_USER SET U_ID= %s WHERE (u_id,u_fname,u_lname,username,password,u_type_id, u_loc_id, u_pnumber) WHERE u_id=1 VALUES(%s, %s, %s, %s, %s, %s, %s, %s)",(u_id,u_fname,u_lname,username,password,u_type_id,u_loc_id, u_pnumber))
        
        con.commit()
    return render_template('updateuser.html')

if __name__ == '__main__':
    app.run()